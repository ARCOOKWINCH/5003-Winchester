"""
Structural Design Pattern: Decorator

I needed one example of a structural design pattern for the brief.
I used the Decorator pattern because it lets you add extra behaviour to an object
by wrapping it, instead of making lots of subclasses for every combination.
This is useful when you want “base behaviour + optional extras” that can be stacked.

Where the idea comes from:
The decorator as a pattern adds behaviours by wrapping
objects inside other objects or wrappers (refactoring.guru, 2025).


The GUI sends one line of text into decorator_demo(raw).
The input format is: flags|message
Example: upper,bracket,prefix=LOG: |hello


I needed a simple way to split "options" (flags) from the "actual text" (message).
Using a pipe is an easy separator because people rarely type it in normal messages.
"""

class Formatter:

    """
    all decorators and the base formatter implement this interface,
    so they can be used interchangeably
    """
    def format(self, msg):
        raise NotImplementedError

# Base formatter that does no formatting
class PlainFormatter(Formatter):
    def format(self, msg):
        return msg

# Decorator that makes text uppercase
class UppercaseDecorator(Formatter):
    def __init__(self, inner):
        self.inner = inner

    def format(self, msg):
        return self.inner.format(msg).upper()

# Decorator that adds brackets around text
class BracketDecorator(Formatter):
    def __init__(self, inner):
        self.inner = inner

    def format(self, msg):
        return "[" + self.inner.format(msg) + "]"

# Decorator that adds a prefix to text
class PrefixDecorator(Formatter):
    def __init__(self, inner, prefix):
        self.inner = inner
        self.prefix = prefix

    def format(self, msg):
        return self.prefix + self.inner.format(msg)

# Function to demonstrate the decorator pattern
def decorator_demo(raw):
    """
    Input format:
      flags|message
    flags can include: upper, bracket, prefix=XYZ
    Example:
      upper,bracket,prefix=LOG: |hello
    """
    if raw is None:
        raw = ""
    raw = raw.strip()
    if raw == "":
        return (
            "Structural Pattern: Decorator\n\n"
            "Format: flags|message\n"
            "Example: upper,bracket,prefix=LOG: |hello"
        )

    if "|" not in raw:
        return "Invalid format. Use: flags|message"

    flags_raw, message = raw.split("|", 1)
    flags = [f.strip() for f in flags_raw.split(",") if f.strip() != ""]
    message = message.strip()

    fmt = PlainFormatter()

    for f in flags:
        if f == "upper":
            fmt = UppercaseDecorator(fmt)
        elif f == "bracket":
            fmt = BracketDecorator(fmt)
        elif f.startswith("prefix="):
            prefix = f[len("prefix="):]
            fmt = PrefixDecorator(fmt, prefix)
        else:
            return f"Unknown flag: {f}"

    result = fmt.format(message)

    return (
        "Structural Pattern: Decorator\n"
        "Decorators wrap an object to add behaviour without changing the base class.\n\n"
        f"Flags: {flags}\n"
        f"Message: {message}\n"
        f"Result: {result}"
    )
