def merge_sort(arr, descending=False):
    """
    Returns a NEW sorted list using merge sort (ascending by default).
    O(n log n) time complexity, O(n) space complexity is guarunteed regarless
    of input order (W3Schools, 2025).
    """
    a = arr[:]
    if len(a) <= 1:
        return a

    mid = len(a) // 2
    left = merge_sort(a[:mid], descending=descending)
    right = merge_sort(a[mid:], descending=descending)

    return _merge(left, right, descending)


def _merge(left, right, descending):
    result = []
    i = 0
    j = 0

    while i < len(left) and j < len(right):
        if descending:
            if left[i] >= right[j]:
                result.append(left[i]); i += 1
            else:
                result.append(right[j]); j += 1
        else:
            if left[i] <= right[j]:
                result.append(left[i]); i += 1
            else:
                result.append(right[j]); j += 1

    while i < len(left):
        result.append(left[i]); i += 1
    while j < len(right):
        result.append(right[j]); j += 1

    return result
