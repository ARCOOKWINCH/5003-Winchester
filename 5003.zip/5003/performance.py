"""
time, random and tracemalloc are used to measure performance (time and memory)
of the algorithms implemented in this application.
"""
import time
import random
import tracemalloc
"""
Modules imported from each .py file in the application, to be tested for performance.

Even though all algorithms could work in the main.py file, importing them into here in order
to test their performance keeps concerns separated and the code cleaner.
Also, it is more time efficient to perform unit tests by creating a performance.py file
that imports all modules to be tested, rather than running each module separately.
"""
from fibonacci import fibonacci_dp
from factorial import factorial_recursive
from bubble_sort import bubble_sort
from selection_sort import selection_sort
from merge_sort import merge_sort
from deck_shuffle import new_deck, fisher_yates_shuffle
from palindrome_counter import count_palindromic_substrings
from rsa import generate_keypair, encrypt_message, decrypt_message
from array_stats import array_stats


def time_it(fn, *args, repeats=5):
    #timings can be noisy, so we run it a few times and keep the best (fastest) run
    best = None
    for _ in range(repeats):
        t0 = time.perf_counter()
        fn(*args)
        t1 = time.perf_counter()
        dt = t1 - t0
        best = dt if best is None else min(best, dt)
    return best


def time_and_memory(fn, *args, repeats=3):
    #tracemalloc lets us see peak memory usage while the function runs
    tracemalloc.start()
    dt = time_it(fn, *args, repeats=repeats)
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return dt, peak


def main():
    random.seed(123)

    # Fibonacci
    for n in [10, 100, 500, 1000]:
        dt, peak = time_and_memory(fibonacci_dp, n, repeats=100)
        print(f"Fibonacci n={n:4d}: {dt:.6f}s peak_mem={peak/1024:.1f}KB")

    # Factorial
    for n in [50, 200, 400, 900]:
        dt, peak = time_and_memory(factorial_recursive, n, repeats=50)
        print(f"Factorial n={n:4d}: {dt:.6f}s peak_mem={peak/1024:.1f}KB")

    # Sorting
    for size in [50, 200, 1000, 3000]:
        arr = [random.randint(-10_000, 10_000) for _ in range(size)]

        dt_b, peak_b = time_and_memory(bubble_sort, arr, repeats=3)
        dt_s, peak_s = time_and_memory(selection_sort, arr, repeats=3)
        dt_m, peak_m = time_and_memory(merge_sort, arr, repeats=3)

        print(
            f"Sort size={size:4d}: "
            f"Bubble: {dt_b:.6f}s {peak_b/1024:.1f}KB  "
            f"Selection: {dt_s:.6f}s {peak_s/1024:.1f}KB  "
            f"Merge: {dt_m:.6f}s {peak_m/1024:.1f}KB"
        )

    # Shuffle (deck is always 52 cards, so it's just measured once)
    deck = new_deck()
    dt, peak = time_and_memory(fisher_yates_shuffle, deck, repeats=50)
    print(f"Deck shuffle (52 cards): {dt:.6f}s peak_mem={peak/1024:.1f}KB")

    # Palindromic substrings
    for n in [50, 100, 200, 400]:
        s = "".join(random.choice("abac") for _ in range(n))
        dt, peak = time_and_memory(count_palindromic_substrings, s, repeats=3)
        print(f"Palindrome len={n:4d}: {dt:.6f}s peak_mem={peak/1024:.1f}KB")

    # RSA small bits for performance testing
    pub, priv = generate_keypair(bits=512)
    msg = "this is a performance test message"

    # Encrypt and decrypt
    dt_e, peak_e = time_and_memory(encrypt_message, msg, pub, repeats=10)
    cipher = encrypt_message(msg, pub)
    dt_d, peak_d = time_and_memory(decrypt_message, cipher, priv, repeats=10)

    print(
        f"RSA Encrypt: {dt_e:.6f}s peak_mem={peak_e/1024:.1f}KB  "
        f"Decrypt: {dt_d:.6f}s peak_mem={peak_d/1024:.1f}KB"
    )

    # Array statistics
    for size in [50, 200, 1000]:
        arr = [random.randint(-10_000, 10_000) for _ in range(size)]
        dt, peak = time_and_memory(array_stats, arr, repeats=10)
        print(f"Array stats size={size:4d}: {dt:.6f}s peak_mem={peak/1024:.1f}KB")


if __name__ == "__main__":
    main()
