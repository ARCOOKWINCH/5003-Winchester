"""
The def builder_demo function below demonstrates the Builder design pattern using a text-based input.

The GUI needs a single function to call when demonstrating the pattern.
User input is parsed and each part is added to the builder step-by-step.
This mirrors the Builder pattern concept described by Refactoring.Guru (refactoring.guru, 2014).

Input format:
title|section1;section2;section3|footer

Example:
Algorithms App|Fibonacci DP;Merge Sort;Design Patterns|Built in Python
"""

class Report:
    """
    The complex object being built which holds the title, sections, and footer.
    it doesn't know about the builder; it just holds data.
    """
    def __init__(self, title, sections, footer):
        self.title = title
        self.sections = sections
        self.footer = footer

    def render(self):
        """
        Renders the report as a formatted string.
        By keeping rendering logic here, Report is responsible for its own format.
        """
        lines = [f"TITLE: {self.title}", ""]
        for i, s in enumerate(self.sections, start=1):
            lines.append(f"Section {i}: {s}")
        lines.append("")
        lines.append(f"FOOTER: {self.footer}")
        return "\n".join(lines)


class ReportBuilder:
    """
    The Builder class constructs the Report object step-by-step.
    Each method returns self to allow method chaining.
    """ 
    def __init__(self):
        self._title = "Untitled"
        self._sections = []
        self._footer = "—"

    def set_title(self, title):
        self._title = title
        return self

    def add_section(self, section_text):
        self._sections.append(section_text)
        return self

    def set_footer(self, footer):
        self._footer = footer
        return self

    def build(self):
        return Report(self._title, self._sections, self._footer)


def builder_demo(raw):
    """
    Input format:
      title|section1;section2;section3|footer
    Example:
      Algorithms App|Fibonacci DP;Merge Sort;Design Patterns|Built in Python
    """
    if raw is None:
        raw = ""
    raw = raw.strip()
    if raw == "":
        return (
            "Creational Pattern: Builder\n\n"
            "Format: title|section1;section2;section3|footer\n"
            "Example: Algorithms App|Fibonacci DP;Merge Sort|Built in Python"
        )

    parts = raw.split("|")
    if len(parts) != 3:
        return "Invalid format. Use: title|section1;section2;...|footer"

    title, sections_raw, footer = parts
    sections = [s.strip() for s in sections_raw.split(";") if s.strip() != ""]

    b = ReportBuilder().set_title(title.strip()).set_footer(footer.strip())
    for s in sections:
        b.add_section(s)

    report = b.build()

    return (
        "Creational Pattern: Builder\n"
        "Builder constructs a complex object step-by-step.\n\n"
        + report.render()
    )
