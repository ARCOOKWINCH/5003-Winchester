'''
the parse_array function prevents empty arrays and ensures all elements are integers.
the bubble_sort function includes an optimization to stop early if the array is already sorted.
'''
def parse_array(text):
    parts = text.split(",")
    nums = []
    for p in parts:
        p = p.strip()
        if p == "":
            continue

        if p.startswith("-"):
            if not p[1:].isdigit():
                raise ValueError("Array must contain only integers.")
        else:
            if not p.isdigit():
                raise ValueError("Array must contain only integers.")

        nums.append(int(p))

    if len(nums) == 0:
        raise ValueError("Array must not be empty.")

    return nums


def bubble_sort(arr):
    a = arr[:]
    n = len(a)

    for i in range(n):
        swapped = False
        for j in range(0, n - 1 - i):
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                swapped = True

                # Optimization: stop if no swaps because the array is already sorted
        if not swapped:
            break

    return a
