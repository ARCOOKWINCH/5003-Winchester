def count_palindromic_substrings(s):
    n = len(s)
    # memo stores results of palindrome checks for substrings (i, j)
    memo = {} 

    def is_pal(i, j):
        """
        this function checks if s[i..j] is a palindrome using recursion with memoization
        with the if statement confirming a single character or empty substring is a palindrome.

        the main problem for checking for palindromes is overlapping subproblems, so we store
        results in a dictionary "memo" to avoid redundant calculations (GeeksforGeeks, 2016). 
        """
        if i >= j:
            return True
        key = (i, j)
        if key in memo:
            return memo[key]
        if s[i] != s[j]:
            memo[key] = False
            return False
        memo[key] = is_pal(i + 1, j - 1)
        return memo[key]

    count = 0
    for i in range(n):
        for j in range(i, n):
            if is_pal(i, j):
                count += 1

    return count
