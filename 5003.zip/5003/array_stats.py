"""
Docstring for displaying array statistics.
Calculates min, max, median, Q1, Q3, mode(s), and returns a sorted version of the array.
"""

from merge_sort import merge_sort

def array_stats(arr):
    if len(arr) == 0:
        raise ValueError("Array must not be empty.")

    sorted_arr = merge_sort(arr, descending=False)

    mn = sorted_arr[0]
    mx = sorted_arr[-1]
    med = _median(sorted_arr)
    q1, q3 = _quartiles(sorted_arr)
    modes = _modes(sorted_arr)

    return {
        "min": mn,
        "max": mx,
        "median": med,
        "q1": q1,
        "q3": q3,
        "mode": modes,  # list (can be 1 or many)
        "sorted": sorted_arr
    }


def _median(sorted_arr):
    n = len(sorted_arr)
    mid = n // 2
    if n % 2 == 1:
        return sorted_arr[mid]
    return (sorted_arr[mid - 1] + sorted_arr[mid]) / 2


def _quartiles(sorted_arr):
    n = len(sorted_arr)
    mid = n // 2

    if n % 2 == 0:
        lower = sorted_arr[:mid]
        upper = sorted_arr[mid:]
    else:
        lower = sorted_arr[:mid]
        upper = sorted_arr[mid + 1:]

    q1 = _median(lower) if len(lower) > 0 else sorted_arr[0]
    q3 = _median(upper) if len(upper) > 0 else sorted_arr[-1]
    return q1, q3


def _modes(sorted_arr):
    # counts frequencies without using collections.Counter
    best_count = 1
    best_values = []

    current_value = sorted_arr[0]
    current_count = 1

    for i in range(1, len(sorted_arr)):
        if sorted_arr[i] == current_value:
            current_count += 1
        else:
            if current_count > best_count:
                best_count = current_count
                best_values = [current_value]
            elif current_count == best_count:
                best_values.append(current_value)

            current_value = sorted_arr[i]
            current_count = 1

    # final run
    if current_count > best_count:
        best_count = current_count
        best_values = [current_value]
    elif current_count == best_count:
        best_values.append(current_value)

    # If every value appears once, "mode" is typically "no mode".
    # Your brief expects a mode, so we return all values if tie at 1.
    if best_count == 1:
        return []

    return best_values
