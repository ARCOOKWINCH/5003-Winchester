import random

"""Deck shuffling module with Fisher-Yates algorithm.

the shuffle algorithm needs a fixed size list to work on, so we provide a new_deck function
that creates a standard 52-card deck.
"""

def new_deck():
    """
    The Fisher-Yates algorithm is unbiased only if the input list has all items equally likely
    to appear in any position. A standard deck of 52 playing cards is a good choice.

    The algorithm works by iterating from the end of the list towards the begining,
    swapping each item with a randomly chosen item that comes before it, including itself (GeeksforGeeks, 2012).

    """

    suits = ["S", "H", "D", "C"]  # Spades, Hearts, Diamonds, Clubs
    ranks = ["A"] + [str(n) for n in range(2, 11)] + ["J", "Q", "K"] # Ace, 2-10, Jack, Queen, King
    return [r + s for s in suits for r in ranks]

# Fisher-Yates shuffle algorithm, because it's unbiased due to its uniform randomness
def fisher_yates_shuffle(deck, seed=None):
    # optional seed for repeatable tests
    if seed is not None and seed != "":
        random.seed(int(seed))

    a = deck[:]  # copy
    n = len(a)
    for i in range(n - 1, 0, -1):
        j = random.randint(0, i)
        a[i], a[j] = a[j], a[i]
    return a
