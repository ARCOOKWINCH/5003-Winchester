"""
main.py - GUI application to run various algorithms

This application provides a simple GUI to select and run different algorithms,
displaying their results in a text box.

It uses tkinter for the GUI, and imports all the algorithms from their respective modules
located in the same directory.

Algorithms included:
- Fibonacci (Dynamic Programming)
- Factorial (Recursion)
- Bubble Sort
- Selection Sort
- Merge Sort
- Deck Shuffle (Fisher–Yates)
- Array Stats (min, max, median, quartiles, mode)
- Palindrome Counter
- RSA (Encrypt/Decrypt) 
- Design Patterns (Builder, Decorator, Command)

The GUI consists of a menu screen to select the algorithm, and an algorithm screen to input
parameters and display results.

The "current_algorithm" variable keeps track of which algorithm is selected without
needing multiple windows.
"""

import tkinter as tk
from tkinter import messagebox

# Algorithms are imported from seperate modules in order to keep the
# GUI code seperated for the purpose of clarity.
from rsa import generate_keypair, encrypt_message, decrypt_message, parse_key
from fibonacci import fibonacci_dp
from factorial import factorial_recursive
from bubble_sort import parse_array, bubble_sort
from selection_sort import selection_sort
from merge_sort import merge_sort
from deck_shuffle import new_deck, fisher_yates_shuffle
from array_stats import array_stats
from palindrome_counter import count_palindromic_substrings
from dp_creational import builder_demo
from dp_structural import decorator_demo
from dp_behavioural import command_demo

# Constants
RSA_NAME = "RSA (Encrypt/Decrypt)"

#
# App window - a single window avoids clutter
#
window = tk.Tk()
window.title("Algorithm App")
window.geometry("380x500")

# variable to track current algorithm
current_algorithm = None

#
# Two main screens - Menu and algorithm screen
# which prevent the need for multiple windows
#
menu_screen = tk.Frame(window)
algorithm_screen = tk.Frame(window)

menu_screen.grid(row=0, column=0, sticky="nsew")
algorithm_screen.grid(row=0, column=0, sticky="nsew")

# Make the frames expand to fill window
window.rowconfigure(0, weight=1)
window.columnconfigure(0, weight=1)

#
# Functions to switch screens
#
def show_menu():
    """
    This allows switching back to the menu screen from the algorithm screen.
    which also resets the current_algorithm variable and clears inputs/outputs.
    """
    global current_algorithm
    current_algorithm = None
    menu_screen.tkraise()


def show_algorithm():
    """
    This allows switching to the algorithm screen from the menu screen.
    """
    algorithm_screen.tkraise()


#
# 1st screen - Menu
#
title = tk.Label(menu_screen, text="5003 Assignment", font=("Arial", 18))
title.pack(pady=10)

selected_label = tk.Label(menu_screen, text="Selected: (none)")
selected_label.pack(pady=5)

# Scrollable area - scrollable frame for algorithm buttons; allowing them to fit
# without expanding the window
canvas = tk.Canvas(menu_screen)
scrollbar = tk.Scrollbar(menu_screen, orient="vertical", command=canvas.yview)
scrollable_frame = tk.Frame(canvas)

scrollable_frame.bind(
    "<Configure>",
    lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
)

canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
canvas.configure(yscrollcommand=scrollbar.set)

canvas.pack(side="left", fill="both", expand=True, padx=10)
scrollbar.pack(side="right", fill="y")


# Algorithm screen widgets (defined early so open_algorithm can access them)
algorithm_title = tk.Label(algorithm_screen, text="(Algorithm)", font=("Arial", 18))
algorithm_title.pack(pady=20)

n_label = tk.Label(algorithm_screen, text="Enter a number (n):")
n_entry = tk.Entry(algorithm_screen, width=35)

array_label = tk.Label(algorithm_screen, text="Enter an array (comma-separated):")
array_entry = tk.Entry(algorithm_screen, width=35)

# Scrollable output box (for RSA keys, stats, etc)
# as the output can be large
output_frame = tk.Frame(algorithm_screen)
output_frame.pack(pady=12, fill="both", expand=True)

output_scrollbar = tk.Scrollbar(output_frame)
output_scrollbar.pack(side="right", fill="y")

output_text = tk.Text(
    output_frame,
    height=12,
    width=70,
    wrap="word",
    yscrollcommand=output_scrollbar.set
)
output_text.pack(side="left", fill="both", expand=True)

output_scrollbar.config(command=output_text.yview)

# RSA mode selection (Encrypt/Decrypt)
# the use of radio buttons allows to switch between decrypt and encrypt modes
rsa_mode_var = tk.StringVar(value="Encrypt")
rsa_mode_frame = tk.Frame(algorithm_screen)
tk.Label(rsa_mode_frame, text="Mode:").pack(side="left", padx=5)
tk.Radiobutton(rsa_mode_frame, text="Encrypt", variable=rsa_mode_var, value="Encrypt").pack(side="left")
tk.Radiobutton(rsa_mode_frame, text="Decrypt", variable=rsa_mode_var, value="Decrypt").pack(side="left")

# centralising the output writing avoids duplicating text widgets across
# all algorithms, as the RSA ouput keys can be large.
def write_output(text):
    output_text.delete("1.0", tk.END)
    output_text.insert(tk.END, text)
    output_text.see(tk.END)


# Algorithm selection logic
def open_algorithm(algo_name):
    """
    This function is called when an algorithm button is clicked on the menu screen.
    because the algorithm screen is shared, this function ensures only the relevent widgets
    are shown for the selected algorithm, and inputs/outputs are cleared.
    """
    global current_algorithm
    current_algorithm = algo_name

    selected_label.config(text=f"Selected: {algo_name}")
    algorithm_title.config(text=f"{algo_name} (Algorithm)")

    # Clear old output and inputs to make sure no old data is shown
    write_output("")
    n_entry.delete(0, tk.END)
    array_entry.delete(0, tk.END)

    n_label.pack_forget()
    n_entry.pack_forget()
    array_label.pack_forget()
    array_entry.pack_forget()
    rsa_mode_frame.pack_forget()

    # by putting the algorithm types into sets, we can easily manage
    # which inputs to show for each algorithm type, in addition to needing
    # less code overall.
    number_algos = {"Fibonacci", "Factorial"}
    array_algos = {"Bubble Sort", "Selection Sort", "Merge Sort", "Array Stats"}
    seed_algos = {"Deck Shuffle"}
    text_algos = {
        "Palindrome Counter",
        "Creational Pattern (Builder)",
        "Structural Pattern (Decorator)",
        "Behavioral Pattern (Command)",
        RSA_NAME,
    }

    if algo_name in number_algos:
        n_label.config(text="Enter a number (n):")
        n_label.pack()
        n_entry.pack(pady=6)

    elif algo_name in array_algos:
        array_label.config(text="Enter an array (comma-separated):")
        array_label.pack()
        array_entry.pack(pady=6)

    elif algo_name in seed_algos:
        n_label.config(text="Optional seed (blank = random):")
        n_label.pack()
        n_entry.pack(pady=6)

    elif algo_name == RSA_NAME:
        array_label.config(text="Enter a message (Encrypt) OR ciphertext integers (Decrypt):")
        array_label.pack()
        array_entry.pack(pady=6)

        n_label.config(text="Key: Encrypt uses n,e (optional). Decrypt requires n,d.")
        n_label.pack()
        n_entry.pack(pady=6)

        rsa_mode_frame.pack(pady=4)

    # the decorator demo needs a special input format in the form of flags|message
    # to specify the desired decorations, with each flag separated by commas.
    # each flag modifies the message in a different way.
    
    elif algo_name == "Structural Pattern (Decorator)":
        array_label.config(
        text="Enter input in the format: flags|message\n"
             "Example: upper,bracket,prefix=LOG: |hello"
    )
    array_label.pack()
    array_entry.pack(pady=6)

    show_algorithm()


# Buttons for each algorithm in the scrollable menu frame
tk.Button(scrollable_frame, text="Fibonacci (DP)", width=30,
          command=lambda: open_algorithm("Fibonacci")).pack(pady=4)

tk.Button(scrollable_frame, text="Factorial (Recursion)", width=30,
          command=lambda: open_algorithm("Factorial")).pack(pady=4)

tk.Button(scrollable_frame, text="Bubble Sort", width=30,
          command=lambda: open_algorithm("Bubble Sort")).pack(pady=4)

tk.Button(scrollable_frame, text="Selection Sort", width=30,
          command=lambda: open_algorithm("Selection Sort")).pack(pady=4)

tk.Button(scrollable_frame, text="Merge Sort", width=30,
          command=lambda: open_algorithm("Merge Sort")).pack(pady=4)

tk.Button(scrollable_frame, text="Deck Shuffle", width=30,
          command=lambda: open_algorithm("Deck Shuffle")).pack(pady=4)

tk.Button(scrollable_frame, text="Array Stats", width=30,
          command=lambda: open_algorithm("Array Stats")).pack(pady=4)

tk.Button(scrollable_frame, text="Palindrome Counter", width=30,
          command=lambda: open_algorithm("Palindrome Counter")).pack(pady=4)

tk.Button(scrollable_frame, text="Creational Pattern (Builder)", width=30,
          command=lambda: open_algorithm("Creational Pattern (Builder)")).pack(pady=4)

tk.Button(scrollable_frame, text="Structural Pattern (Decorator)", width=30,
          command=lambda: open_algorithm("Structural Pattern (Decorator)")).pack(pady=4)

tk.Button(scrollable_frame, text="Behavioral Pattern (Command)", width=30,
          command=lambda: open_algorithm("Behavioral Pattern (Command)")).pack(pady=4)

tk.Button(scrollable_frame, text=RSA_NAME, width=30,
          command=lambda: open_algorithm(RSA_NAME)).pack(pady=4)


# Run button logic
def run_button_clicked():
    """
    this function is called when the "Run" button is clicked the algorithm screen.
    It checks which algorithm is currently selected, retrieves the inputs.
    """
    if current_algorithm is None:
        write_output("No algorithm selected.")
        return

    if current_algorithm == "Fibonacci":
        n_text = n_entry.get().strip()
        if n_text == "":
            messagebox.showwarning("Input missing", "Please enter a number.")
            return
        if not n_text.isdigit():
            messagebox.showerror("Invalid input", "Please enter a non-negative integer.")
            return
        n = int(n_text)
        write_output(f"Fibonacci number F({n}) = {fibonacci_dp(n)}")
        return

    if current_algorithm == "Factorial":
        n_text = n_entry.get().strip()
        if n_text == "":
            messagebox.showwarning("Input missing", "Please enter a number.")
            return
        if not n_text.isdigit():
            messagebox.showerror("Invalid input", "Please enter a non-negative integer.")
            return
        n = int(n_text)
        write_output(f"Factorial of {n} = {factorial_recursive(n)}")
        return

    if current_algorithm == "Bubble Sort":
        arr_text = array_entry.get().strip()
        if arr_text == "":
            messagebox.showwarning("Input missing", "Please enter an array, e.g. 3, 1, 2")
            return
        try:
            arr = parse_array(arr_text)
        except ValueError as e:
            messagebox.showerror("Invalid array", str(e))
            return
        write_output(f"Original: {arr}\nSorted (Bubble): {bubble_sort(arr)}")
        return

    if current_algorithm == "Selection Sort":
        arr_text = array_entry.get().strip()
        if arr_text == "":
            messagebox.showwarning("Input missing", "Please enter an array, e.g. 3, 1, 2")
            return
        try:
            arr = parse_array(arr_text)
        except ValueError as e:
            messagebox.showerror("Invalid array", str(e))
            return
        write_output(f"Original: {arr}\nSorted (Selection): {selection_sort(arr, descending=False)}")
        return

    if current_algorithm == "Merge Sort":
        arr_text = array_entry.get().strip()
        if arr_text == "":
            messagebox.showwarning("Input missing", "Please enter an array, e.g. 3, 1, 2")
            return
        try:
            arr = parse_array(arr_text)
        except ValueError as e:
            messagebox.showerror("Invalid array", str(e))
            return
        write_output(f"Original: {arr}\nSorted (Merge): {merge_sort(arr, descending=False)}")
        return

    if current_algorithm == "Deck Shuffle":
        seed_text = n_entry.get().strip()
        if seed_text != "" and not seed_text.isdigit():
            messagebox.showerror("Invalid seed", "Seed must be a whole number or blank.")
            return

        # A new deck is created each time to maintain randomness
        deck = new_deck()
        shuffled = fisher_yates_shuffle(deck, seed=seed_text if seed_text != "" else None)

        # For ease of reading, this shows the deck in 4 rows of 13 cards
        lines = []
        for i in range(0, 52, 13):
            lines.append("  ".join(shuffled[i:i+13]))

        seed_info = f"Seed: {seed_text}" if seed_text != "" else "Seed: (random)"
        write_output("Deck Shuffle (Fisher–Yates)\n" + seed_info + "\n\n" + "\n".join(lines))
        return

    if current_algorithm == "Array Stats":
        arr_text = array_entry.get().strip()
        if arr_text == "":
            messagebox.showwarning("Input missing", "Please enter an array, e.g. 1, 2, 2, 3")
            return
        try:
            arr = parse_array(arr_text)
        except ValueError as e:
            messagebox.showerror("Invalid array", str(e))
            return

        stats = array_stats(arr)
        mode_list = stats["mode"]
        mode_str = "No mode" if mode_list == [] else ", ".join(str(x) for x in mode_list)

        write_output(
            "Array Stats\n"
            f"Original: {arr}\n"
            f"Sorted:   {stats['sorted']}\n\n"
            f"Min:    {stats['min']}\n"
            f"Max:    {stats['max']}\n"
            f"Median: {stats['median']}\n"
            f"Q1:     {stats['q1']}\n"
            f"Q3:     {stats['q3']}\n"
            f"Mode:   {mode_str}\n"
        )
        return

    if current_algorithm == "Palindrome Counter":
        s = array_entry.get().strip()
        if s == "":
            messagebox.showwarning("Input missing", "Please enter a string, e.g. abba")
            return
        write_output(f"Input: {s}\nPalindromic substrings: {count_palindromic_substrings(s)}")
        return

    if current_algorithm == "Behavioral Pattern (Command)":
        write_output(command_demo(array_entry.get().strip()))
        return

    if current_algorithm == "Creational Pattern (Builder)":
        write_output(builder_demo(array_entry.get().strip()))
        return

    if current_algorithm == "Structural Pattern (Decorator)":
        write_output(decorator_demo(array_entry.get().strip()))
        return

    if current_algorithm == RSA_NAME:
        mode = rsa_mode_var.get()
        msg_or_cipher = array_entry.get().strip()
        key_text = n_entry.get().strip()

        if msg_or_cipher == "":
            messagebox.showwarning("Input missing", "Please enter a message or ciphertext.")
            return

        try:
            if mode == "Encrypt":
                if key_text == "":
                    public_key, private_key = generate_keypair(bits=512)
                    cipher = encrypt_message(msg_or_cipher, public_key)

                    write_output(
                        "RSA Encrypt\n\n"
                        f"Ciphertext:\n{cipher}\n\n"
                        "Generated keys (save these):\n"
                        f"Public (n,e): {public_key[0]},{public_key[1]}\n"
                        f"Private (n,d): {private_key[0]},{private_key[1]}\n"
                    )
                    # Note: In a real application, private keys should be handled securely.
                    # however, for this demonstration the key is shown to the user.
                else:
                    public_key = parse_key(key_text)  # n,e
                    cipher = encrypt_message(msg_or_cipher, public_key)
                    write_output(
                        "RSA Encrypt\n\n"
                        f"Ciphertext:\n{cipher}\n\n"
                        f"Used Public (n,e): {public_key[0]},{public_key[1]}"
                    )
            else:
                if key_text == "":
                    messagebox.showerror("Missing key", "Decrypt requires a private key in the form n,d.")
                    return
                private_key = parse_key(key_text)  # n,d
                plain = decrypt_message(msg_or_cipher, private_key)
                write_output(
                    "RSA Decrypt\n\n"
                    f"Plaintext:\n{plain}\n\n"
                    f"Used Private (n,d): {private_key[0]},{private_key[1]}"
                )

        except Exception as e:
            messagebox.showerror("RSA error", str(e))
        return

    write_output("No algorithm matched your selection (check button names).")


# Action buttons remain on the algorithm screen to allow the user to select new algorithms
tk.Button(algorithm_screen, text="Run", width=12, command=run_button_clicked).pack(pady=4)
tk.Button(algorithm_screen, text="Back", width=12, command=show_menu).pack(pady=4)

# Starts the application on the menu screen
show_menu()
window.mainloop()
