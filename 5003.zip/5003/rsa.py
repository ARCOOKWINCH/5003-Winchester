import random
from math import gcd

"""RSA encryption/decryption module.

Implements key generation, encryption, decryption, and key parsing.

Uses Miller-Rabin primality test for generating probable primes.
"""

# Extended Euclidean Algorithm
def egcd(a, b):
    """Extended GCD: returns (g, x, y) such that ax + by = g = gcd(a,b)."""
    if b == 0:
        return a, 1, 0
    g, x1, y1 = egcd(b, a % b)
    return g, y1, x1 - (a // b) * y1


def modinv(a, m):
    """
    Modular inverse of a mod m, if it exists.

    RSA encryption requires finding d such that ed ≡ 1 (mod φ(n)).
    which means d is the modular inverse of e mod φ(n) (GeeksforGeeks, 2017).
    
    """
    g, x, _ = egcd(a, m)
    if g != 1:
        raise ValueError("No modular inverse exists for these values.")
    return x % m


def is_probable_prime(n, k=10):
    """
    Miller-Rabin primality test.

    RSA key generation needs large prime numbers. The Miller-Rabin test is a probabilistic test that
    can quickly identify non-prime numbers (composites) and confirm probable primes.
    
    """
    if n < 2:
        return False
    small_primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
    for p in small_primes:
        if n == p:
            return True
        if n % p == 0:
            return False

    # write n-1 as d * 2^s
    d = n - 1
    s = 0
    while d % 2 == 0:
        d //= 2
        s += 1

    # witness loop
    for _ in range(k):
        a = random.randrange(2, n - 2)
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for __ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def generate_prime(bits):
    """Generate a probable prime of given bit length."""
    if bits < 16:
        raise ValueError("Use at least 16 bits for primes.")
    while True:
        # ensure odd and correct bit-length
        candidate = random.getrandbits(bits) | (1 << (bits - 1)) | 1
        if is_probable_prime(candidate):
            return candidate


# RSA key generation
def generate_keypair(bits=512, e=65537):
    """
    Returns (public_key, private_key)
    public_key  = (n, e)
    private_key = (n, d)

    RSA uses two prime numbers p and q to compute n = p * q and φ(n) = (p-1)(q-1).
    n = p*q is used as the modulus for both keys.
    e is chosen such that 1 < e < φ(n) and gcd(e, φ(n)) = 1.
    d is computed as the modular inverse of e mod φ(n).
    The public key (n, e) is used for encryption, and the private key (n, d) is used for decryption.
    """
    if bits < 256:
        raise ValueError("Use at least 256 bits for RSA keys.")
    # Uses at least 256 bits for RSA keys. However, 2048+ bits is recommended for real security (Villanueva, 2017).

    half = bits // 2

    while True:
        p = generate_prime(half)
        q = generate_prime(half)
        if p == q:
            continue

        n = p * q
        phi = (p - 1) * (q - 1)

        if gcd(e, phi) != 1:
            continue

        d = modinv(e, phi)
        return (n, e), (n, d)


def _max_block_bytes(n):
    """
    Max bytes per plaintext block so that block < n.
    """
    # n.bit_length() gives bits; convert to bytes
    # We keep one byte safety margin.
    return max(1, (n.bit_length() // 8) - 1)


def encrypt_message(message, public_key):
    """
    Encrypts a UTF-8 string.
    Returns ciphertext as a space-separated string of integers.
    """
    n, e = public_key
    data = message.encode("utf-8")

    block_size = _max_block_bytes(n)
    blocks = [data[i:i + block_size] for i in range(0, len(data), block_size)]

    cipher_ints = []
    for b in blocks:
        m = int.from_bytes(b, byteorder="big")
        if m >= n:
            raise ValueError("Message block too large for this key.")
        c = pow(m, e, n)
        cipher_ints.append(str(c))

    return " ".join(cipher_ints)


def decrypt_message(ciphertext, private_key):
    """
    Decrypts a space-separated string of integers back to a UTF-8 string.
    """
    n, d = private_key
    ciphertext = ciphertext.strip()
    if ciphertext == "":
        return ""

    parts = ciphertext.split()
    out_bytes = bytearray()

    for part in parts:
        if not part.isdigit():
            raise ValueError("Ciphertext must be space-separated integers.")
        c = int(part)
        m = pow(c, d, n)

        # Convert int back to bytes (minimal length)
        block = m.to_bytes((m.bit_length() + 7) // 8 or 1, byteorder="big")
        out_bytes.extend(block)

    return out_bytes.decode("utf-8", errors="strict")


def parse_key(key_text):
    """
    Parses keys in the format: n,e  or  n,d  (comma-separated).
    Returns (n, exponent).
    """
    key_text = (key_text or "").strip()
    if "," not in key_text:
        raise ValueError("Key must be in the format n,e or n,d (comma-separated).")
    a, b = key_text.split(",", 1)
    a = a.strip()
    b = b.strip()
    if not (a.isdigit() and b.isdigit()):
        raise ValueError("Key values must be integers.")
    return int(a), int(b)
