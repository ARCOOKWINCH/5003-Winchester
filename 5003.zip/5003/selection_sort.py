def selection_sort(arr, descending=False):
    """
    turns a NEW sorted list using selection sort (ascending by default).
    O(n^2) time complexity, O(1) space complexity (GeeksforGeeks, 2014).

    takes a copy of the input array to avoid modifying it.
    """
    a = arr[:]  # copy
    n = len(a)

    for i in range(n):
        best_idx = i
        for j in range(i + 1, n):
            if descending:
                if a[j] > a[best_idx]:
                    best_idx = j
            else:
                if a[j] < a[best_idx]:
                    best_idx = j
        a[i], a[best_idx] = a[best_idx], a[i]

    return a
