"""
Demonstrates the Command design pattern using a simple text example.

The GUI needs a single function to run the Command pattern demo.
Each piece of user input is turned into a command object.
The final command is undone to show how undo works.

Based on the Command pattern concept described by Refactoring.Guru (refactoring.guru, 2014).

Input format:
Comma-separated text chunks, e.g.  Hello, world, !
"""

# Base Command interface, with execute and undo methods

class Command:
    """
    All comands should support the same operations so they can be handled uniformly.
    This allows the Command Manager to run and undo commands without knowing details.
    """
    def execute(self):
        raise NotImplementedError

    def undo(self):
        raise NotImplementedError


class TextBuffer:
    def __init__(self):
        self.text = ""

    def append(self, s: str):
        self.text += s

    def delete_last(self, k: int):
        if k <= 0:
            return
        self.text = self.text[:-k]

# Concrete Command that appends text to the buffer
class AppendCommand(Command):
    """
    This wraps the action of appending text to a TextBuffer.
    It knows how to execute (append) and undo (delete last).
    """
    def __init__(self, buffer: TextBuffer, to_add: str):
        self.buffer = buffer
        self.to_add = to_add

    def execute(self):
        self.buffer.append(self.to_add)

    def undo(self):
        self.buffer.delete_last(len(self.to_add))

# Manager that runs and tracks commands for undo
class CommandManager:
    """
    Manafges executing commands and supports undoing the last command.
    It keeps a history stack of executed commands.
    """
    def __init__(self):
        self.history = []

    def run(self, cmd: Command):
        cmd.execute()
        self.history.append(cmd)

    def undo_last(self):
        if not self.history:
            return False
        cmd = self.history.pop()
        cmd.undo()
        return True

# Function to demonstrate the command pattern
def command_demo(user_input: str) -> str:
    """
    Input format (simple):
      comma-separated chunks, e.g.  Hello, world, !
    The demo will append each chunk as a command, then undo the last command.
    """
    parts = [p.strip() for p in (user_input or "").split(",") if p.strip() != ""]
    if not parts:
        return "Behavioral Pattern: Command\n\nEnter comma-separated text chunks, e.g. Hello, world, !"

    buf = TextBuffer()
    mgr = CommandManager()

    out = ["Behavioral Pattern: Command (with undo)\n"]
    for p in parts:
        cmd = AppendCommand(buf, p)
        mgr.run(cmd)
        out.append(f"Executed: append('{p}') -> buffer='{buf.text}'")

    undone = mgr.undo_last()
    if undone:
        out.append(f"\nUndo last command -> buffer='{buf.text}'")
    else:
        out.append("\nNothing to undo.")

    return "\n".join(out)
